package com.example.xuberance2021

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
