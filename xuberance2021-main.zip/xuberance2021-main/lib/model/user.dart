import 'package:fpdart/fpdart.dart';
import 'package:xuberance2021/model/school.dart';

class User {
  late final School school;

  User({
    required this.school,
  });
}
